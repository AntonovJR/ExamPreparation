package viceCity.core;

import viceCity.core.interfaces.Controller;
import viceCity.models.guns.Gun;
import viceCity.models.guns.Pistol;
import viceCity.models.guns.Rifle;
import viceCity.models.players.CivilPlayer;
import viceCity.models.players.MainPlayer;
import viceCity.models.players.Player;
import viceCity.repositories.interfaces.GunRepository;
import viceCity.repositories.interfaces.Repository;

import java.util.*;
import java.util.stream.Collectors;

import static viceCity.common.ConstantMessages.*;

public class ControllerImpl implements Controller {
    private Player mainPlayer;
    private Map<String, Player> players;
    private Deque<Gun> guns;


    public ControllerImpl() {
        this.players = new LinkedHashMap<>();
        this.mainPlayer = new MainPlayer();
        this.players.put("Tommy Vercetti", mainPlayer);
        this.guns = new ArrayDeque<>();
    }

    @Override
    public String addPlayer(String name) {
        Player player = new CivilPlayer(name);
        this.players.put(name, player);
        return String.format(PLAYER_ADDED, name);
    }

    @Override
    public String addGun(String type, String name) {
        Gun gun;
        switch (type) {
            case "Rifle":
                gun = new Rifle(name);
                break;
            case "Pistol":
                gun = new Pistol(name);
                break;
            default:
                return GUN_TYPE_INVALID;
        }
        guns.offer(gun);
        return String.format(GUN_ADDED, name, type);
    }

    @Override
    public String addGunToPlayer(String name) {

        if (name.equals("Vercetti")) {
            Gun gun = this.guns.poll();
            if (gun == null) {
                return GUN_QUEUE_IS_EMPTY;
            }
            this.players.get("Tommy Vercetti").getGunRepository().add(gun);
            return String.format(GUN_ADDED_TO_MAIN_PLAYER, gun.getName(), "Tommy Vercetti");
        } else if (!players.containsKey(name)) {
            return CIVIL_PLAYER_DOES_NOT_EXIST;

        } else {
            Gun gun = this.guns.poll();
            if (gun == null) {
                return GUN_QUEUE_IS_EMPTY;
            }
            this.players.get(name).getGunRepository().add(gun);
            return String.format(GUN_ADDED_TO_CIVIL_PLAYER, gun.getName(), name);
        }
    }

    @Override
    public String fight() {
        Player player = this.players.remove(MainPlayer.NAME);
        int killedPlayers = 0;
        for (Gun gun : player.getGunRepository().getModels()) {
            while (gun.canFire()) {
                int fire = gun.fire();
                List<Player> values = new ArrayList<>(this.players.values());
                Player hitPlayer = values.get(0);
                hitPlayer.takeLifePoints(fire);
                if (!hitPlayer.isAlive()) {
                    killedPlayers++;
                    this.players.remove(hitPlayer.getName());
                }
            }
        }
        StringBuilder db = new StringBuilder();
        db.append("A fight happened:").append(System.lineSeparator());
        db.append(String.format("Tommy live points: %d", mainPlayer.getLifePoints())).append(System.lineSeparator());
        db.append(String.format("Tommy has killed: %d", killedPlayers)).append(System.lineSeparator());
        db.append(String.format("Left Civil Players: %d", players.size() - killedPlayers)).append(System.lineSeparator());

        return db.toString().trim();
    }
}
