package viceCity.models.guns;

public class Rifle extends BaseGun {
    public static final int BULLETS_CAN_FIRE = 5;

    public Rifle(String name) {
        super(name, 50, 500);
    }

    @Override
    public boolean canFire() {
        if (getBulletsPerBarrel() > BULLETS_CAN_FIRE) {
            return true;
        } else if (getBulletsPerBarrel() == 0 && getTotalBullets() > BULLETS_CAN_FIRE) {
            reload();
            return true;
        }
        return false;
    }

    private void reload() {
        setBulletsPerBarrel(50);
        setTotalBullets(getTotalBullets() - getBulletsPerBarrel());
    }

    @Override
    public int fire() {
        setBulletsPerBarrel(getBulletsPerBarrel() - BULLETS_CAN_FIRE);
        return 5;

    }
}