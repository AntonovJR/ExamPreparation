package viceCity.models.players;

public class MainPlayer extends BasePlayer{
    public static final String NAME = "Tommy Vercetti";

    public MainPlayer() {
        super(NAME, 100);
    }
}
