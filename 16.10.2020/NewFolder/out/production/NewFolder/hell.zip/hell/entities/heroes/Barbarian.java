package hell.entities.heroes;

import hell.interfaces.Item;

import java.util.Collection;

public class Barbarian extends Heroes{
    public Barbarian(String name, int strength, int agility, int intelligence, int hitPoints, int damage, Collection<Item> itemsList) {
        super(name, strength, agility, intelligence, hitPoints, damage, itemsList);
    }
}
