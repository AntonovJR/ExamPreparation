package hell.entities.items;

import hell.interfaces.Item;

public abstract class Items implements Item {
    private String name;
    private int strengthBonus;
    private int agilityBonus;
    private int intelligenceBonus;
    private int hitPointsBonus;
    private int damageBonus;

    protected Items(String name, int strengthBonus, int agilityBonus, int intelligenceBonus, int hitPointsBonus, int damageBonus) {
        this.setName(name);
        this.setStrengthBonus(strengthBonus);
        this.setAgilityBonus(agilityBonus);
        this.setIntelligenceBonus(intelligenceBonus);
        this.setHitPointsBonus(hitPointsBonus);
        this.setDamageBonus(damageBonus);
    }

    private void setName(String name) {
        this.name = name;
    }

    private void setStrengthBonus(int strengthBonus) {
        this.strengthBonus = strengthBonus;
    }

    private void setAgilityBonus(int agilityBonus) {
        this.agilityBonus = agilityBonus;
    }

    private void setIntelligenceBonus(int intelligenceBonus) {
        this.intelligenceBonus = intelligenceBonus;
    }

    private void setHitPointsBonus(int hitPointsBonus) {
        this.hitPointsBonus = hitPointsBonus;
    }

    private void setDamageBonus(int damageBonus) {
        this.damageBonus = damageBonus;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getStrengthBonus() {
        return 0;
    }

    @Override
    public int getAgilityBonus() {
        return 0;
    }

    @Override
    public int getIntelligenceBonus() {
        return 0;
    }

    @Override
    public int getHitPointsBonus() {
        return 0;
    }

    @Override
    public int getDamageBonus() {
        return 0;
    }
}
