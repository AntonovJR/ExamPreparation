package hell.entities.heroes;

import hell.interfaces.Hero;
import hell.interfaces.Item;
import hell.interfaces.Recipe;

import java.util.ArrayList;
import java.util.Collection;

public abstract class Heroes implements Hero {

    private String name;
    private int strength;
    private int agility;
    private int intelligence;
    private int hitPoints;
    private int damage;
    private Collection<Item> itemsList;

    protected Heroes(String name, int strength, int agility, int intelligence, int hitPoints, int damage, Collection<Item> itemsList) {
        this.setName(name);
        this.setStrength(strength);
        this.setAgility(agility);
        this.setIntelligence(intelligence);
        this.setHitPoints(hitPoints);
        this.setDamage(damage);
        this.itemsList = new ArrayList<>();
    }

    private void setName(String name) {
        this.name = name;
    }

    private void setStrength(int strength) {
        this.strength = strength;
    }

    private void setAgility(int agility) {
        this.agility = agility;
    }

    private void setIntelligence(int intelligence) {
        this.intelligence = intelligence;
    }

    private void setHitPoints(int hitPoints) {
        this.hitPoints = hitPoints;
    }

    private void setDamage(int damage) {
        this.damage = damage;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public long getStrength() {
        return 0;
    }

    @Override
    public long getAgility() {
        return 0;
    }

    @Override
    public long getIntelligence() {
        return 0;
    }

    @Override
    public long getHitPoints() {
        return 0;
    }

    @Override
    public long getDamage() {
        return 0;
    }

    @Override
    public Collection<Item> getItems() {
        return null;
    }

    @Override
    public void addItem(Item item) {

    }

    @Override
    public void addRecipe(Recipe recipe) {

    }
}
