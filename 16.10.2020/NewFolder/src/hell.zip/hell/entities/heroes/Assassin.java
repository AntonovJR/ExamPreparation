package hell.entities.heroes;

import hell.interfaces.Item;

import java.util.Collection;

public class Assassin extends Heroes{
    public Assassin(String name) {
        super(name, 25, 100, 15, 150, 300);
    }
}
