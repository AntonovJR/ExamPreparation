package cresla.entities.reactors;

public class HeatReactor extends Reactors {
    private int heatReductionIndex;

    public HeatReactor(int id, int heatReductionIndex) {
        super(id);
        this.setHeatReductionIndex(heatReductionIndex);
    }

    private void setHeatReductionIndex(int heatReductionIndex) {
        this.heatReductionIndex = heatReductionIndex;
    }
}
