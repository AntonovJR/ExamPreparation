package cresla.entities.modules;

import cresla.interfaces.AbsorbingModule;

public class CooldownSystem extends Modules implements AbsorbingModule {
    private int heatAbsorbing ;

    public CooldownSystem(int id, int heatAbsorbing) {
        super(id);
        this.setHeatAbsorbing(heatAbsorbing);
    }

    private void setHeatAbsorbing(int heatAbsorbing) {
        this.heatAbsorbing = heatAbsorbing;
    }

    @Override
    public int getHeatAbsorbing() {
        return 0;
    }
}
