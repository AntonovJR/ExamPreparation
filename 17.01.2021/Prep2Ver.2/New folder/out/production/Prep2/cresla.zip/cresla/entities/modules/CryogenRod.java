package cresla.entities.modules;

import cresla.interfaces.EnergyModule;

public class CryogenRod extends Modules implements EnergyModule {
    private int energyOutput;

    public CryogenRod(int id, int energyOutput) {
        super(id);
        this.setEnergyOutput(energyOutput);
    }

    private void setEnergyOutput(int energyOutput) {
        this.energyOutput = energyOutput;
    }

    @Override
    public int getEnergyOutput() {
        return 0;
    }
}
