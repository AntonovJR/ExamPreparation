package cresla.entities.reactors;

import cresla.interfaces.AbsorbingModule;
import cresla.interfaces.EnergyModule;
import cresla.interfaces.Reactor;

public abstract class Reactors implements Reactor {
    private int id;

    protected Reactors(int id) {
        this.setId(id);
    }

    private void setId(int id) {
        this.id = id;
    }

    @Override
    public int getId() {
        return 0;
    }

    @Override
    public long getTotalEnergyOutput() {
        return 0;
    }

    @Override
    public long getTotalHeatAbsorbing() {
        return 0;
    }

    @Override
    public int getModuleCount() {
        return 0;
    }

    @Override
    public void addEnergyModule(EnergyModule energyModule) {

    }

    @Override
    public void addAbsorbingModule(AbsorbingModule absorbingModule) {

    }
}
