package cresla.entities.modules;

import cresla.interfaces.AbsorbingModule;

public class HeatProcessor extends Modules implements AbsorbingModule {
    private int heatAbsorbing ;

    public HeatProcessor(int id, int heatAbsorbing) {
        super(id);
        this.setHeatAbsorbing(heatAbsorbing);
    }

    private void setHeatAbsorbing(int heatAbsorbing) {
        this.heatAbsorbing = heatAbsorbing;
    }

    @Override
    public int getHeatAbsorbing() {
        return 0;
    }
}
