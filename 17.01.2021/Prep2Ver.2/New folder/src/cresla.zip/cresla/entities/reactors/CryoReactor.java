package cresla.entities.reactors;

public class CryoReactor extends Reactors {
    private int cryoProductionIndex;

    public CryoReactor(int id, int cryoProductionIndex) {
        super(id);
        this.setCryoProductionIndex(cryoProductionIndex);
    }

    private void setCryoProductionIndex(int cryoProductionIndex) {
        this.cryoProductionIndex = cryoProductionIndex;
    }

}
