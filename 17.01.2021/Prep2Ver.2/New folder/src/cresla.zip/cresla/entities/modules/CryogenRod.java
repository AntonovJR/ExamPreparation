package cresla.entities.modules;

import cresla.interfaces.EnergyModule;

public class CryogenRod extends EnergyModules  {
    private int energyOutput;

    public CryogenRod(int id, int energyOutput) {
        super(id);
        this.setEnergyOutput(energyOutput);
    }

    private void setEnergyOutput(int energyOutput) {
        this.energyOutput = energyOutput;
    }

}
