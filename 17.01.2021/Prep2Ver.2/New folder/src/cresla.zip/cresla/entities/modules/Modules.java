package cresla.entities.modules;

import cresla.interfaces.Module;

public abstract class Modules implements Module {
    private int id;

    protected Modules(int id) {
        this.setId(id);
    }

    private void setId(int id) {
        this.id = id;
    }

    @Override
    public int getId() {
        return 0;
    }
}
