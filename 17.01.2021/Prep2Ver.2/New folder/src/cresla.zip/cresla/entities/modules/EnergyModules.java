package cresla.entities.modules;

import cresla.interfaces.EnergyModule;

public abstract class EnergyModules extends Modules implements EnergyModule {
    protected EnergyModules(int id) {
        super(id);
    }

    @Override
    public int getEnergyOutput() {
        return 0;
    }
}
