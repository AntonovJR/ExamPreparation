package CounterStriker.repositories;

import CounterStriker.models.players.Player;

import java.util.ArrayList;
import java.util.Collection;

public class PlayerRepository<T extends Player> implements Repository<T>{
    Collection<T> players;

    public PlayerRepository() {
        this.players = new ArrayList<>();
    }

    @Override
    public Collection<T> getModels() {
        return this.players;
    }

    @Override
    public void add(T model) {
        players.add(model);

    }

    @Override
    public boolean remove(T model) {
        return players.remove(model);
    }

    @Override
    public T findByName(String name) {
        return this.players.stream().filter(m-> m.getUsername().equals(name)).findFirst().orElse(null);
    }
}